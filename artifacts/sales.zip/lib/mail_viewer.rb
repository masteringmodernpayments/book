class MailViewer < MailView
  def receipt
    product = Product.create!(name: 'Test Product')
    sale = Sale.create!(
      guid: 'abc-123',
      product: product,
      amount: 1300,
      card_type: 'Visa',
      card_last4: '1234',
      email: 'test@example.com',
      stripe_token: 'tok_12345',
    )
    mail = ReceiptMailer.receipt(sale.id)
    sale.destroy
    product.destroy
    mail
  end
  def refund
    product = Product.create!(name: 'Test Product')
    sale = Sale.create!(
      guid: 'abc-123',
      product: product,
      amount: 1300,
      card_type: 'Visa',
      card_last4: '1234',
      email: 'test@example.com',
      stripe_token: 'tok_12345',
    )
    mail = ReceiptMailer.refund(sale.id)
    sale.destroy
    product.destroy
    mail
  end

  def admin_receipt
    product = Product.create!(name: 'Test Product')
    sale = Sale.create!(
      guid: 'abc-123',
      product: product,
      amount: 1300,
      card_type: 'Visa',
      card_last4: '1234',
      email: 'test@example.com',
      stripe_token: 'tok_12345',
    )
    mail = AdminMailer.receipt(sale.id)
    sale.destroy
    product.destroy
    mail
  end

  def admin_refund
    product = Product.create!(name: 'Test Product')
    sale = Sale.create!(
      guid: 'abc-123',
      product: product,
      amount: 1300,
      card_type: 'Visa',
      card_last4: '1234',
      email: 'test@example.com',
      stripe_token: 'tok_12345',
    )
    mail = AdminMailer.refund(sale.id)
    sale.destroy
    product.destroy
    mail
  end

  def admin_dispute
    product = Product.create!(name: 'Test Product')
    sale = Sale.create!(
      guid: 'abc-123',
      product: product,
      amount: 1300,
      card_type: 'Visa',
      card_last4: '1234',
      email: 'test@example.com',
      stripe_token: 'tok_12345',
    )
    mail = AdminMailer.dispute(sale.id)
    sale.destroy
    product.destroy
    mail
  end
end
