class AddIndexes < ActiveRecord::Migration
  def change
    add_index :products, :user_id
    add_index :sales, :product_id
  end
end
