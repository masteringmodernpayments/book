class AddDownloadUrlToProduct < ActiveRecord::Migration
  def change
    change_table :products do |t|
      t.text :download_url
    end
  end
end
