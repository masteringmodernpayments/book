class AddFieldsToSale < ActiveRecord::Migration
  def change
    add_column :sales, :state, :string
    add_column :sales, :stripe_id, :string
    add_column :sales, :stripe_token, :string
    add_column :sales, :card_last4, :string
    add_column :sales, :card_expiration, :string
    add_column :sales, :card_type, :string
    add_column :sales, :error, :text
    add_column :sales, :amount, :integer
    add_column :sales, :fee_amount, :integer
  end
end
