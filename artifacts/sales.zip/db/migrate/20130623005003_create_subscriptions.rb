class CreateSubscriptions < ActiveRecord::Migration
  def change
    create_table :subscriptions do |t|
      t.integer :plan_id
      t.integer :member_id
      t.string :state

      t.timestamps
    end
  end
end
