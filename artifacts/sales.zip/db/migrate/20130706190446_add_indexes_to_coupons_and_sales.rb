class AddIndexesToCouponsAndSales < ActiveRecord::Migration
  def change
    add_index :coupons, :user_id
    add_index :sales, :coupon_id
  end
end
