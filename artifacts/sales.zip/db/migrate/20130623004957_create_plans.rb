class CreatePlans < ActiveRecord::Migration
  def change
    create_table :plans do |t|
      t.integer :user_id
      t.string :stripe_id
      t.integer :amount
      t.string :interval

      t.timestamps
    end
  end
end
