class AddDownloadCounterToSales < ActiveRecord::Migration
  def change
    add_column :sales, :download_count, :integer
  end
end
