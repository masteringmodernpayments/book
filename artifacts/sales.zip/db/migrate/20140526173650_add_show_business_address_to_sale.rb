class AddShowBusinessAddressToSale < ActiveRecord::Migration
  def change
    add_column :sales, :business_address, :text
  end
end
