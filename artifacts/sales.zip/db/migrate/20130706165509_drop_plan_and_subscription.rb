class DropPlanAndSubscription < ActiveRecord::Migration
  def change
    drop_table :subscriptions
    drop_table :plans
    drop_table :members
  end
end
