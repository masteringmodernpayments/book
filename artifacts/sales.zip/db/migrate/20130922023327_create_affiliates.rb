class CreateAffiliates < ActiveRecord::Migration
  def change
    create_table :affiliates do |t|
      t.string :code
      t.string :email
      t.integer :percent
      t.integer :user_id

      t.timestamps
    end
  end
end
