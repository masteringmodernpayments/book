class ChangeCardExpirationToDate < ActiveRecord::Migration
  def up
    execute <<-SQL
      ALTER TABLE sales ALTER COLUMN card_expiration TYPE date USING card_expiration::date
    SQL
  end

  def down
    change_column :sales, :card_expiration, :string
  end
end
