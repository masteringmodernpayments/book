class AddStripeIdToMember < ActiveRecord::Migration
  def change
    add_column :members, :stripe_id, :string
  end
end
