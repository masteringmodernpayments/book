class AddOptInToSale < ActiveRecord::Migration
  def change
    add_column :sales, :opt_in, :boolean
  end
end
