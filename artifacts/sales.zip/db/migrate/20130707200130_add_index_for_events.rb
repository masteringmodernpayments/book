class AddIndexForEvents < ActiveRecord::Migration
  def change
    add_index :events, [:stripe_id, :stripe_type]
  end
end
