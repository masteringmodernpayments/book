class AddAffiliateIdToSale < ActiveRecord::Migration
  def change
    change_table :sales do |t|
      t.integer :affiliate_id
    end
  end
end
