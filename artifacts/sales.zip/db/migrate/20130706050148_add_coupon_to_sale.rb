class AddCouponToSale < ActiveRecord::Migration
  def change
    add_column :sales, :coupon_id, :integer
  end
end
