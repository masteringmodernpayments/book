class AddCustomerAddressToSale < ActiveRecord::Migration
  def change
    add_column :sales, :customer_address, :text
  end
end
