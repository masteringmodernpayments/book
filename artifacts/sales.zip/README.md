# Sales

This is the application that is running on https://sales.petekeen.com. It is a storefront that sells downloadable products like ebooks or videos. It uses:

* [Stripe](https://www.stripe.com) for payment processing
* [Rails](http://rubyonrails.org) as the overall framework
* [PostgreSQL](http://www.postgresql.org) for data storage
* [Devise](https://github.com/plataformatec/devise) for user authentication
* [Dotenv](https://github.com/bkeepers/dotenv) for configuration management
* [PaperTrail](https://github.com/airblade/paper_trail) for audit trails
* [SuckerPunch](https://github.com/brandonhilkert/sucker_punch) to process background jobs
* [Brakeman](http://brakemanscanner.org) for security analysis
* [Rails Best Practices](https://github.com/railsbp/rails_best_practices) to ensure correct code

## Installation

```
$ cd sales
$ heroku create
$ heroku config STRIPE_PUBLISHABLE_KEY=your_stripe_key STRIPE_SECRET_KEY=your_stripe_secret SECRET_TOKEN=rails_secret_token
$ # remove or comment out the asset_host line in config/environments/production.rb
$ git push heroku master
```

## Configuration Variables

* `STRIPE_PUBLISHABLE_KEY` Provided by Stripe. Required.
* `STRIPE_SECRET_KEY` Provided by Stripe. Required.
* `SECRET_TOKEN` Sets the Rails secret token. Required.
* `DATABASE_URL` The database to use. Provided by Heroku. Required.
* `SMTP_SERVER_ADDRESS` Required for sending emails.
* `SMTP_SERVER_PORT` Required for sending emails.
* `SMTP_SERVER_USERNAME` Required for sending emails.
* `SMTP_SERVER_PASSWORD` Required for sending emails.
* `SMTP_SERVER_DOMAIN` Required for sending emails.
* `APP_DOMAIN` Required for sending emails. Set this to the full domain name for your application. On my production site this is `sales.petekeen.net`.
* `STRIPE_MANAGE_BASE_URL` Sets up a link from the admin sale view page to the corresponding Stripe page.
* `ASSET_HOST` Sets up Rails' asset host behavior. Optional.
* `NOTIFIER_FROM_ADDRESS` Sets the From address for error notification emails. Optional.
* `NOTIFIER_TO_ADDRESS` Sets the To address for error notification emails. Optional, but if you want emails you need to set both From and To.
* `GOOGLE_ANALYTICS_ACCOUNT_ID` Sets up Google Analytics tracking. Optional.
* `GOOGLE_ANALYTICS_DOMAIN_NAME` Sets up Google Analytics tracking. Optional.
* `MIXPANEL_ACCOUNT_ID` Sets up Mixpanel tracking. Optional.

## Usage

Create a user:

```
$ heroku run console
irb> User.create!(email: 'you@example.com', password: 'password', password_confirmation: 'password)
```

Navigate to your app, login as the user you just created, add some products. Link to `https://your-app.herokuapp.com/buy/your-product-permalink` to direct buyers to products.

