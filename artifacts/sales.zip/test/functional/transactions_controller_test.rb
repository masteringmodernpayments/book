require 'test_helper'

class TransactionsControllerTest < ActionController::TestCase

  include Devise::TestHelpers

  setup do
    @product = FactoryGirl.create(:product)
    Stripe.api_key = "pk_abc123"
  end

  test "should get new" do
    get :new, permalink: @product.permalink
    assert_response :success
    assert_not_nil assigns(:product)
  end

  test "should get iframe" do
    get :iframe, permalink: @product.permalink

    assert_response :success
    assert_not_nil assigns(:product)
  end

  test "should get show" do
    sale = FactoryGirl.create(:sale)
    get :show, guid: sale.guid

    assert_response :success
    assert_not_nil assigns(:sale)
  end

  test "should post create" do
    token = 'tok_1234567'
    email = 'foo@example.com'
    sale = FactoryGirl.create(:sale, email: email, stripe_token: token, product: @product, state: 'finished')

    Sale.expects(:create_for_product_token_email).with do |args|
      args[:product]      == @product &&
      args[:stripe_token] == token &&
      args[:email]        == email
    end.returns(sale)

    post :create, permalink: @product.permalink, stripeToken: 'tok_1234567', email: 'foo@example.com'

    assert_response :success
    assert_not_nil assigns(:sale)
  end

  test "should post create with coupon code" do
    token = 'tok_1234567'
    email = 'foo@example.com'
    coupon = FactoryGirl.create(:coupon)
    sale = FactoryGirl.create(:sale, email: email, stripe_token: token, product: @product, state: 'finished', coupon: coupon)

    Sale.expects(:create_for_product_token_email).with do |args|
      args[:product]      == @product &&
      args[:stripe_token] == token &&
      args[:email]        == email &&
      args[:coupon_id]    == coupon.id
    end.returns(sale)

    post :create, permalink: @product.permalink, stripeToken: 'tok_1234567', email: 'foo@example.com', coupon_code: coupon.code

    assert_response :success
    assert_not_nil assigns(:sale)
  end

  test "should post create with mixed case coupon code" do
    token = 'tok_1234567'
    email = 'foo@example.com'
    coupon = FactoryGirl.create(:coupon, code: "123TestCode")
    sale = FactoryGirl.create(:sale, email: email, stripe_token: token, product: @product, state: 'finished', coupon: coupon)

    Sale.expects(:create_for_product_token_email).with do |args|
      args[:product]      == @product &&
      args[:stripe_token] == token &&
      args[:email]        == email &&
      args[:coupon_id]    == coupon.id
    end.returns(sale)

    post :create, permalink: @product.permalink, stripeToken: 'tok_1234567', email: 'foo@example.com', coupon_code: "123TESTcoDe"

    assert_response :success
    assert_not_nil assigns(:sale)
  end

  test "should getting new with affiliate code creates cookie" do
    affiliate = FactoryGirl.create(:affiliate)
    get :new, permalink: @product.permalink, aff: affiliate.code

    assert_equal affiliate.code, cookies[:aff]
  end

  test "should post create with opt_in" do
    token = 'tok_1234567'
    email = 'foo@example.com'
    sale = FactoryGirl.create(:sale, email: email, stripe_token: token, product: @product, state: 'finished', opt_in: true)

    Sale.expects(:create_for_product_token_email).with do |args|
      args[:product]      == @product &&
      args[:stripe_token] == token &&
      args[:email]        == email &&
      args[:opt_in]       == true
    end.returns(sale)


    post :create, permalink: @product.permalink, stripeToken: 'tok_1234567', email: 'foo@example.com', opt_in: true

    assert_response :success
    assert_not_nil assigns(:sale)
  end

  test "should get status" do
    sale = FactoryGirl.create(:sale)

    get :status, guid: sale.guid

    assert_response :success

    assert_equal 'pending', JSON.parse(response.body)['status']
  end

  test "should get download" do
    sale = FactoryGirl.create(:sale)
    get :download, guid: sale.guid
    assert_response :success
    assert_equal sale, assigns(:sale)
  end

  test "should increment download count" do
    sale = FactoryGirl.create(:sale)

    get :download, guid: sale.guid
    get :download, guid: sale.guid

    assert_equal 2, sale.reload.download_count
  end

  test "buy should have page title" do
    product = FactoryGirl.create(:product)
    get :new, permalink: product.permalink
    assert_match(/Buy #{product.name} \| Pete Keen Sales/, response.body)
  end
end
