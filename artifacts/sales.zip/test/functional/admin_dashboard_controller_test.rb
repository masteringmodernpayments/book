require 'test_helper'

class Admin::DashboardControllerTest < ActionController::TestCase

  include Devise::TestHelpers

  setup do
    @user = FactoryGirl.create(:user)
    @sale = FactoryGirl.create(:sale, guid: 'foobarbaz')
    sign_in @user
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:recent_sales)
    assert_not_nil assigns(:last_day_sales)
    assert_not_nil assigns(:last_week_sales)
  end

  test "should search" do
    post :search, q: 'foob'
    assert_response :success
    assert_equal @sale, assigns(:sales).first
  end
end
