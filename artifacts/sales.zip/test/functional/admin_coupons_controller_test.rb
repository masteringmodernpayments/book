require 'test_helper'

class Admin::CouponsControllerTest < ActionController::TestCase

  include Devise::TestHelpers

  setup do
    @user = FactoryGirl.create(:user)
    @coupon = FactoryGirl.create(:coupon, user: @user)
    sign_in @user
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:coupons)
  end

  test "should create coupon" do
    post :create, coupon: {code: 'TESTCODE', percent_off: 10}

    assert_redirected_to admin_coupon_path(Coupon.last)
    assert_not_nil assigns(:coupon)
    assert_equal "TESTCODE", assigns(:coupon).code
    assert_equal 10, assigns(:coupon).percent_off
  end

  test "should delete coupon" do
    delete :destroy, {id: @coupon.id}
    assert_redirected_to admin_coupons_path
  end

  test "should edit coupon" do
    get :edit, {id: @coupon.id}
    assert_response :success
  end

  test "should update coupon" do
    patch :update, {id: @coupon.id, coupon: {percent_off: 30}}
    assert_redirected_to admin_coupon_path(Coupon.last)
    assert_not_nil assigns(:coupon)
    assert_equal 30, assigns(:coupon).percent_off
  end

end
