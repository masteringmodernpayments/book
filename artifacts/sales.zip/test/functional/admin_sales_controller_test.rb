require 'test_helper'

class Admin::SalesControllerTest < ActionController::TestCase

  include Devise::TestHelpers

  setup do
    @sale = FactoryGirl.create(:sale)
    @user = FactoryGirl.create(:user)
    sign_in @user
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:sales)
  end

  test "should show sale" do
    get :show, id: @sale
    assert_response :success
  end

  test "should show new" do
    get :new
    assert_response :success
  end

  test "should create" do
    post :create, sale: {email: 'foo@blah.example.com', product_id: @sale.product.id}
    assert assigns(:sale)
    assert_equal 'foo@blah.example.com', assigns(:sale).email
    assert_equal @sale.product.id, assigns(:sale).product_id
    assert_equal @sale.product.price, assigns(:sale).amount
    assert_equal 'manual', assigns(:sale).stripe_token
  end

  test "should create with custom payment method" do
    post :create, sale: {email: 'foo@blah.example.com', product_id: @sale.product.id, stripe_token: 'foo'}
    assert_equal 'foo', assigns(:sale).stripe_token
  end

  test "should create with custom amount" do
    post :create, sale: {email: 'foo@blah.example.com', product_id: @sale.product.id, amount: "123"}
    assert_equal 123, assigns(:sale).amount
  end
end
