require 'test_helper'

class EventsControllerTest < ActionController::TestCase

  include Devise::TestHelpers

  def test_charge_dispute_created
    event_id = 'fake_event_id'
    sale = FactoryGirl.create(:sale, stripe_id: 'abc123')

    mock_event = mock
    mock_data = mock
    mock_charge = mock

    mock_event.expects(:data).returns(mock_data)
    mock_data.expects(:object).returns(mock_charge)
    mock_charge.expects(:id).returns('abc123').at_least_once

    Stripe::Event.expects(:retrieve).with(event_id).at_least_once.returns(mock_event)

    post :create, id: event_id, type: 'charge.dispute.created'
  end

  def test_charge_refunded
    event_id = 'fake_event_id'
    sale = FactoryGirl.create(:sale, stripe_id: 'abc123', state: 'finished')

    mock_event = mock
    mock_data = mock
    mock_charge = mock

    mock_event.expects(:data).returns(mock_data)
    mock_data.expects(:object).returns(mock_charge)
    mock_charge.expects(:id).returns('abc123').at_least_once

    Stripe::Event.expects(:retrieve).with(event_id).at_least_once.returns(mock_event)

    post :create, id: event_id, type: 'charge.refunded'
  end

  def test_charge_succeeded
    event_id = 'fake_event_id'
    sale = FactoryGirl.create(:sale, stripe_id: 'abc123', state: 'finished')

    mock_event = mock
    mock_data = mock
    mock_charge = mock

    mock_event.expects(:data).returns(mock_data)
    mock_data.expects(:object).returns(mock_charge)
    mock_charge.expects(:id).returns('abc123').at_least_once

    Stripe::Event.expects(:retrieve).with(event_id).at_least_once.returns(mock_event)

    post :create, id: event_id, type: 'charge.succeeded'
  end

end
