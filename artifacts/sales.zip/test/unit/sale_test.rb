require 'test_helper'

class SaleTest < ActiveSupport::TestCase
  test "should create_for_product_token_email" do
    product = FactoryGirl.create(:product)

    sale = Sale.create_for_product_token_email(
      product: product,
      stripe_token: 'token',
      email: 'foo@exmaple.com'
    )

    sale.save!

    assert sale
    assert sale.pending?
  end

  test "should create_for_product_token_email with coupon" do
    product = FactoryGirl.create(:product)
    coupon = FactoryGirl.create(:coupon)

    sale = Sale.create_for_product_token_email(
      product: product,
      stripe_token: 'token',
      email: 'foo@example.com',
      coupon_id: coupon.id
    )

    sale.save!

    assert sale
    assert_equal 900, sale.amount
  end

  test "should create_for_product_token_email with affiliate" do
    product = FactoryGirl.create(:product)
    affiliate = FactoryGirl.create(:affiliate)

    sale = Sale.create_for_product_token_email(
      product: product,
      stripe_token: 'token',
      email: 'foo@example.com',
      affiliate: affiliate
    )

    sale.save!
    assert sale
    assert_equal affiliate.id, sale.affiliate_id
  end

  test "real scope" do
    FactoryGirl.create(:sale, state: 'finished', email: 'test@example.com', amount: 100)
    FactoryGirl.create(:sale, state: 'finished', email: 'test@bugsplat.info', amount: 100)
    
    assert_equal 1, Sale.real.count
    assert_equal 100, Sale.real.sum(:amount)
  end

  test "search guid" do
    sale = FactoryGirl.create(:sale, guid: 'foobarbaz')

    assert_equal sale, Sale.search('foo').first
    assert_equal sale, Sale.search('baz').first
  end

  test "search email" do
    sale = FactoryGirl.create(:sale, email: 'zomg@gmail.net')

    assert_equal sale, Sale.search('zomg').first
    assert_equal sale, Sale.search('gmail.net').first
  end

  test "search last4" do
    sale = FactoryGirl.create(:sale, card_last4: '4242')

    assert_equal sale, Sale.search('4242').first
  end

  test "admin_create" do
    product = FactoryGirl.create(:product)
    sale = Sale.admin_create(product_id: product.id, email: 'foo@bugsplat.info', stripe_token: 'blah')
    assert_equal product.price, sale.amount
    assert_equal 'foo@bugsplat.info', sale.email
    assert_equal 'blah', sale.stripe_token
  end

  test "admin_create with amount" do
    product = FactoryGirl.create(:product)
    sale = Sale.admin_create(product_id: product.id, email: 'foo@bugsplat.info', stripe_token: 'blah', amount: "123")
    assert_equal 123, sale.amount
  end

  test "charge_card respects old api" do
    product = FactoryGirl.create(:product)
    sale = Sale.create(product_id: product.id, email: "foo@bugsplat.info", stripe_token: "test_token", amount: 123)

    mock_card = mock()
    mock_card.expects(:last4).returns("1234")
    mock_card.expects(:exp_year).returns(2015)
    mock_card.expects(:exp_month).returns(1)
    mock_card.expects(:type).returns("Visa")

    mock_charge = mock()

    mock_charge.expects(:fee).returns(1).at_least_once
    mock_charge.expects(:id).returns('test_charge').at_least_once
    mock_charge.expects(:card).returns(mock_card).at_least_once

    mock_customer = mock()
    mock_customer.expects(:id).returns('test_customer').at_least_once

    Stripe::Customer.expects(:create).with() do |args|
      args[:email] == 'foo@bugsplat.info'
      args[:card] == 'test_token'
    end.returns(mock_customer)

    Stripe::Charge.expects(:create).with() do |args|
      args[:amount] == 123
      args[:currency] == "usd"
      args[:customer] == 'test_customer'
      args[:description] == sale.guid
    end.returns(mock_charge)

    sale.expects(:finish!)

    sale.charge_card
  end

  test "charge_card respects new api" do
    product = FactoryGirl.create(:product)
    sale = Sale.create(product_id: product.id, email: "foo@bugsplat.info", stripe_token: "test_token", amount: 123)

    mock_card = mock()
    mock_card.expects(:last4).returns("1234")
    mock_card.expects(:exp_year).returns(2015)
    mock_card.expects(:exp_month).returns(1)
    mock_card.expects(:type).returns("Visa")

    mock_charge = mock()

    mock_charge.expects(:id).returns('test_charge').at_least_once
    mock_charge.expects(:card).returns(mock_card).at_least_once
    mock_charge.expects(:balance_transaction).returns("test_balance_transaction")

    mock_customer = mock()
    mock_customer.expects(:id).returns('test_customer').at_least_once

    Stripe::Customer.expects(:create).with() do |args|
      args[:email] == 'foo@bugsplat.info'
      args[:card] == 'test_token'
    end.returns(mock_customer)

    Stripe::Charge.expects(:create).with() do |args|
      args[:amount] == 123
      args[:currency] == "usd"
      args[:customer] == 'test_customer'
      args[:description] == sale.guid
    end.returns(mock_charge)

    mock_balance_transaction = mock()
    mock_balance_transaction.expects(:fee).returns(1)

    Stripe::BalanceTransaction.expects(:retrieve).with("test_balance_transaction").returns(mock_balance_transaction)

    sale.expects(:finish!)

    sale.charge_card
  end
end
