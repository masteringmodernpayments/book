require 'test_helper'

class SalesHelperTest < ActionView::TestCase
end
