require 'test_helper'

class ReceiptMailerTest < ActionMailer::TestCase
  tests ReceiptMailer

  test "receipt" do
    sale = FactoryGirl.create(:sale)
    mail = ReceiptMailer.receipt(sale.id).deliver

    assert !ActionMailer::Base.deliveries.empty?

    assert_equal [sale.email], mail.to
    assert_equal ['pete@petekeen.net'], mail.from
    assert_match sale.guid, mail.html_part.to_s
    assert_equal "Purchase confirmation and download link", mail.subject
  end

  test "refund" do
    sale = FactoryGirl.create(:sale)
    mail = ReceiptMailer.refund(sale.id).deliver

    assert !ActionMailer::Base.deliveries.empty?

    assert_equal [sale.email], mail.to
    assert_equal ['pete@petekeen.net'], mail.from
    assert_equal "Refund confirmation", mail.subject
  end
end
