FactoryGirl.define do
  sequence :email do |n|
    "person#{n}@example.com"
  end

  sequence :code do |n|
    "coupon#{n}"
  end

  sequence :permalink do |n|
    "product-#{n}"
  end

  factory :product do
    permalink
    description "product description"
    price 1000
    user
    file File.open(File.expand_path('../25.gif', __FILE__))
  end

  factory :sale do
    email
    product
    stripe_token "tok_token"
  end

  factory :user do
    email
    password "password"
    password_confirmation "password"
  end

  factory :coupon do
    user
    code
    percent_off 10
  end

  factory :affiliate do
    user
    code
    percent 20
  end
end
