(function() {
    document.write('<script src="/jquery.colorbox-min.js"></script>');
    var script = $('script[src$="checkout.js"]');
    var permalink = script.data('permalink');
    document.write('<a class="buy-' + permalink + '" href="/buy/' + permalink + '">Buy</a>');
    $(".buy-" + permalink).colorbox({iframe: true, width: '300px', height: '300px'});
})();
