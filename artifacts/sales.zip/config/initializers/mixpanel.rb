Rails.configuration.mixpanel = {
  account_id: ENV['MIXPANEL_ACCOUNT_ID'],
  enabled: Rails.env.production?
}
