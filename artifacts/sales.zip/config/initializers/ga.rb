Rails.configuration.google_analytics = {
  account_id: ENV['GOOGLE_ANALYTICS_ACCOUNT_ID'],
  domain_name: ENV['GOOGLE_ANALYTICS_DOMAIN_NAME'],
  enabled: Rails.env.production?
}
  
