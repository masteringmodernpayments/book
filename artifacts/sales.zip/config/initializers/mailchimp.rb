Rails.configuration.mailchimp = {
  enabled: Rails.env.production? && ENV['MAILCHIMP_LIST_ID'],
  list_id: ENV['MAILCHIMP_LIST_ID']
}
