Rails.configuration.twitter_ads = {
  account_id: ENV['TWITTER_ADS_ACCOUNT_ID'],
  enabled: Rails.env.production?
}
