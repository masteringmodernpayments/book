Rails.configuration.perfect_audience = {
  key: ENV['PERFECT_AUDIENCE_KEY'],
  enabled: Rails.env.production?
}
