require 'sidekiq/web'

Sales::Application.routes.draw do
  match '/buy/:permalink'    => 'transactions#new',      via: :get,  as: :show_buy
  match '/buy/:permalink'    => 'transactions#create',   via: :post, as: :buy
  match '/confirm/:guid'     => 'transactions#show',     via: :get,  as: :confirm
  match '/pickup/:guid'      => 'transactions#pickup',   via: :get,  as: :pickup
  match '/iframe/:permalink' => 'transactions#iframe',   via: :get,  as: :buy_iframe
  match '/download/:guid'    => 'transactions#download', via: :get,  as: :download
  match '/status/:guid'      => 'transactions#status',   via: :get,  as: :status

  resources :events, only: [:create]

  namespace :admin do
    root :to => 'dashboard#index'
    match '/search' => 'dashboard#search', via: :get, as: :search
    resources :sales do
      member do
        get 'receipt'
        get 'queue'
      end
    end
    resources :products
    resources :coupons
    resources :affiliates
    authenticate :user do
      mount Sidekiq::Web => '/sidekiq'
      mount MailViewer => '/mail'
    end
  end
  devise_for :users

  root :to => 'transactions#index'
end
