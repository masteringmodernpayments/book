class ApplicationController < ActionController::Base
  protect_from_forgery

  protected
  def set_page_title(title)
    @page_title = title
  end
end
