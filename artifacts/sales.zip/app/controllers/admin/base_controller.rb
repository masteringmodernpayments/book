class Admin::BaseController < ApplicationController
  before_filter :authenticate_user!
  layout 'admin'

  respond_to :html
  inherit_resources

  def attrs_for_index
    []
  end

  def attrs_for_form
    []
  end

  helper_method :attrs_for_index
  helper_method :attrs_for_form
end
