class Admin::CouponsController < Admin::BaseController
  protected
  def permitted_params
    params.permit(:coupon => [:code, :percent_off])
  end

  def begin_of_association_chain
    current_user
  end

  def collection
    @coupons ||= end_of_association_chain.order('created_at')
  end

  def attrs_for_form
    [:code, :percent_off]
  end

  def attrs_for_index
    [:code, :percent_off]
  end
end
