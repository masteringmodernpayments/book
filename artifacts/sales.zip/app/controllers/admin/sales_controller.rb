class Admin::SalesController < Admin::BaseController
  # GET /sales
  # GET /sales.json
  def index
    @sales = Sale.order('created_at desc')
    set_page_title "All Sales"

    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @sales }
    end
  end

  # GET /sales/1
  # GET /sales/1.json
  def show
    @sale = Sale.find(params[:id])
    set_page_title @sale.guid

    respond_to do |format|
      format.html # show.html.erb
      format.json { render json: @sale }
    end
  end

  def new
    @sale = Sale.new
    set_page_title "Create New Sale"
  end

  def create
    @sale = Sale.admin_create(sale_params)
    redirect_to admin_sale_path(@sale)
  end

  def update
    @sale = Sale.find(params[:id])
    @sale.update_attributes(sale_params)
    @sale.save!
    redirect_to admin_sale_path(@sale)
  end

  def receipt
    @sale = Sale.find(params[:id])
    @product = @sale.product
    set_page_title "Receipt for #{@sale.guid}"

    respond_to do |format|
      format.html do
        render 'receipt_mailer/receipt_pdf.html', layout: false
      end
      format.pdf do
        html = render_to_string 'receipt_mailer/receipt_pdf.html', layout: false
        pdf = Docverter::Conversion.run do |c|
          c.from = 'html'
          c.to = 'pdf'
          c.content = html
        end
        send_data pdf, filename: 'receipt.pdf', content_type: 'application/pdf'
      end
    end
  end

  def queue
    @sale = Sale.find(params[:id])
    @sale.queue_job
    flash[:notice] = "Job Queued"
    redirect_to admin_sale_path(@sale)
  end

  private
  def sale_params
    params.require(:sale).permit(:product_id, :amount, :email, :stripe_token, :customer_address, :business_address)
  end
end
