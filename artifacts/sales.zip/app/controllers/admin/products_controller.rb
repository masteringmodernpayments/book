class Admin::ProductsController < Admin::BaseController
  protected
  def permitted_params
    params.permit(:product => [:description, :name, :permalink, :price, :file])
  end

  def begin_of_association_chain
    current_user
  end

  def collection
    @products ||= end_of_association_chain.order('created_at')
  end

  def attrs_for_form
    [:name, :permalink, :description, :price, :file]
  end

  def attrs_for_index
    [:permalink, :price]
  end
end
