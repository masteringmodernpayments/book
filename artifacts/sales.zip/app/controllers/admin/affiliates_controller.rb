class Admin::AffiliatesController < Admin::BaseController
  protected
  def permitted_params
    params.permit(:affiliate => [:code, :email, :percent])
  end

  def attrs_for_form
    [:code, :email, :percent]
  end

  def attrs_for_index
    [:code, :email, :percent]
  end

  def begin_of_association_chain
    current_user
  end
end
