class Admin::DashboardController < Admin::BaseController
  include ActionView::Helpers::DateHelper

  def index
    set_page_title "Admin Dashboard"
    @recent_sales = Sale.real.order('created_at DESC').limit(10)
    @last_day_sales = Sale.finished.today.sum(:amount)
    @last_week_sales = Sale.finished.this_week.sum(:amount)
    @all_time_sales = Sale.finished.real.sum(:amount)

    @sales_by_product = ActiveRecord::Base.connection.select_all("select product_id, sum(amount) as sales_amount, count(1) as sales_count from sales where email !~ 'bugsplat' group by product_id order by product_id")
    @sales_by_product = @sales_by_product.map do |sale|
      product = Product.where(id: sale['product_id'].to_i).first
      next unless product
      {
        product: product,
        amount: sale['sales_amount'].to_i,
        count: sale['sales_count'],
      }
    end.compact
  end

  def search
    @sales = Sale.search(params[:q])
    set_page_title "Search"
  end
end
