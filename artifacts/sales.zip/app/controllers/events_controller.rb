class EventsController < ApplicationController
  before_filter :parse_and_validate_event

  def create
    if self.class.private_method_defined? event_method
      self.send(event_method, @event.stripe_event_object)
    end
    render nothing: true
  end

  private

  def event_method
    "stripe_#{@event.stripe_type.gsub('.', '_')}"
  end

  def parse_and_validate_event

    @event = Event.new(stripe_id: params['id'], stripe_type: params['type'])

    unless @event.save
      if @event.valid?
        # valid event, can't be saved for some other reason
        render :nothing => true, status: 400
      else
        # invalid event. move along.
        render :nothing => true
      end
    end
  end

  def stripe_charge_dispute_created(charge)
    sale = Sale.find_by(stripe_id: charge.id)
    return unless sale
    AdminMailer.delay.dispute(sale.id)
  end

  def stripe_charge_refunded(charge)
    sale = Sale.find_by(stripe_id: charge.id)
    return unless sale
    sale.refund!
  end

  def stripe_charge_succeeded(charge)
    sale = Sale.find_by!(stripe_id: charge.id)
    AdminMailer.delay.receipt(sale.id)
  end

end
