module ApplicationHelper
  def formatted_price(amount)
    sprintf("$%0.2f", (amount || 0) / 100.0)
  end

  def page_title
    parts = ["Pete Keen Sales"]
    parts.unshift @page_title if @page_title
    parts.join(" | ")
  end

  def google_analytics_enabled?
    Rails.configuration.google_analytics[:enabled] && Rails.configuration.google_analytics[:account_id]
  end

  def mixpanel_enabled?
    Rails.configuration.mixpanel[:enabled] && Rails.configuration.mixpanel[:account_id]
  end

  def perfect_audience_enabled?
    Rails.configuration.perfect_audience[:enabled] && Rails.configuration.perfect_audience[:key]
  end

  def twitter_ads_enabled?
    Rails.configuration.twitter_ads[:enabled] && Rails.configuration.twitter_ads[:account_id]
  end
end
