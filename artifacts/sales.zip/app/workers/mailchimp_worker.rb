class MailchimpWorker

  include Sidekiq::Worker

  def perform(guid)
    ActiveRecord::Base.connection_pool.with_connection do
      sale = Sale.find_by(guid: guid)
      gb = Gibbon::API.new
      gb.lists.batch_subscribe(
        id: Rails.configuration.mailchimp[:list_id],
        update_existing: true,
        double_optin: false,
        batch: [{
          email: {email: sale.email},
          merge_vars: {
            PRODUCT: sale.product.permalink,
            PURCH: 't',
            GUID: sale.guid,
            AMOUNT: sale.amount,
            PURCHAT: sale.created_at.strftime('%Y-%m-%d %H:%M:%S')
          }
        }]
      )
    end
  end
end
