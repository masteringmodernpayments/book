class ReceiptMailer < ActionMailer::Base
  add_template_helper ApplicationHelper
  layout 'email'
  default from: "Pete Keen <pete@petekeen.net>"

  def receipt(sale_id)
    ActiveRecord::Base.connection_pool.with_connection do
      @sale = Sale.find(sale_id)
      @product = @sale.product

      html = render_to_string('receipt_mailer/receipt_pdf.html', layout: false)

      pdf = Docverter::Conversion.run do |c|
        c.from = 'html'
        c.to = 'pdf'
        c.content = html
      end

      attachments['receipt.pdf'] = pdf
      mail(to: @sale.email, subject: 'Purchase confirmation and download link')
    end
  end

  def refund(sale_id)
    ActiveRecord::Base.connection_pool.with_connection do
      @sale = Sale.find(sale_id)
      @product = @sale.product

      mail(to: @sale.email, subject: 'Refund confirmation')
    end
  end
end
