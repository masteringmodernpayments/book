class AdminMailer < ActionMailer::Base
  add_template_helper ApplicationHelper

  default from: "admin@petekeen.net"
  default to: "admin@petekeen.net"

  def receipt(sale_id)
    ActiveRecord::Base.connection_pool.with_connection do
      @sale = Sale.find(sale_id)
      @product = @sale.product
      mail
    end
  end

  def refund(sale_id)
    ActiveRecord::Base.connection_pool.with_connection do
      @sale = Sale.find(sale_id)
      @product = @sale.product
      mail
    end
  end

  def dispute(sale_id)
    ActiveRecord::Base.connection_pool.with_connection do
      @sale = Sale.find(sale_id)
      @product = @sale.product
      mail
    end
  end
end
